# dataset 불러오기
library(readxl)
game_data <- read_excel("full_game.xlsx")

# tibble -> data.frame으로 테이블 형태 변환 
game_data <- as.data.frame(game_data)
View(game_data)

# 데이터 살펴보기
head(game_data)

# 데이터 타입
str(game_data)

# NA 값 확인
table(is.na(game_data))
nrow(game_data)

# dataset 전처리(중지 행은 미리 파일에서 삭제함.) dplyr 사용 이유? r 내장 함수로 전처리하는 것 보다 가독성이 뛰어남, 속도도 훌륭
library(dplyr)

# 회귀분석에 사용할 열로만 새로운 dataset 생성
# cast(분야), name(유튜버), sub(구독자수), like(좋아요수), hate(싫어요수), view(조회수), ad(광고 여부), comm_count(댓글수)
data_game = game_data %>% select(cast, name, sub, like, hate, view, ad, comm_count)
head(data_game)
table(data_game$ad)
str(data_game)
# 좋아요수, 싫어요수가 '확인필요' 즉, 유튜버가 좋아요/싫어요 기능을 막아둔 경우 해당 유튜버의 좋아요 수, 싫어요 수의 평균 값으로 대체  

# 유튜버별 좋아요 수 평균
youtuber_like_mean = data_game %>% 
  group_by(name) %>%
  summarise(mean_like = round(mean(like)))

youtuber_like_mean
  
# 유튜버별 싫어요 수 평균
youtuber_hate_mean = data_game %>% 
  group_by(name) %>%
  summarise(mean_like = round(mean(hate)))

youtuber_hate_mean
table(data_game$like)

# 좋아요 수, 싫어요 수의 평균 값으로 '확인필요'인 경우 대체
# data_game$like = ifelse((data_game$name == 'G-ZONE 게임은지원') & (data_game$like == '확인필요' ), youtuber_like_mean[1, 2], data_game$like)
# data_game$hate = ifelse((data_game$name == 'G-ZONE 게임은지원') & (data_game$hate == '확인필요' ), youtuber_hate_mean[1, 2], data_game$hate)

# 데이터 타입 변환 name, ad 각각 문자, 숫자형이였지만 as.factor을 이용하여 형변환을 시켜준다. 범주형 변수로 변경!
data_game$name = as.factor(data_game$name)
data_game$ad = as.factor(data_game$ad)

# 단순통계량
str(data_game)
summary(data_game)

# 자료진단: 이상치 확인 
# library(ggplot2)
# ggplot(data=data_game, aes(x=ad, y=log(like))) + geom_boxplot(aes(fill=ad))

# 회귀분석

# 목적변수가 like인 경우 -> x=(name, ad), y=like
game.lm.like = lm(like ~ ad + name, data = data_game)
summary(game.lm.like)

# 등분산성, 정규성, 등분산성(이상점), 이상점 확인
par(mfrow=c(2,2))
plot(game.lm.like)

# 반응변수 변수변환을 위한 boxcox
library(MASS)
par(mfrow=c(1,1))
bc_game.lm.like <- boxcox(game.lm.like)
lambda <- bc_game.lm.like$x[which.max(bc_game.lm.like$y)]
lambda

# lambda: 0.1010101 -> 반올림 후 lambda가 0.1로 0에 가까우므로 log() 변환함.
game.lm.like.log = lm(log(like) ~ ad + name, data = data_game)
summary(game.lm.like.log)


# 등분산성, 정규성, 등분산성(이상점), 이상점 확인
par(mfrow=c(2,2))
plot(game.lm.like.log)


# 정규성 검정
# shapiro.test(game_data$like)

# cook d
# table(cooks.distance(game.lm.like.log) > 1)

# 오차항의 정규성: Shapiro-Wilk < Kolmogorove-Smirnov / 표본 수(n)이 7000개 이상이므로
# ks.test(game.lm.like$residuals, "pnorm")

# 오차항의 독립성: Durbin-Watson test
# install.packages("car")
# library(car)
# durbinWatsonTest(game.lm.like.log)

# 오차항의 등분산성
# ncvTest(game.lm.like.log)

# 모형의 선형성
# crPlots(game.lm.like.log)

# 목적변수가 hate인 경우 -> x=(name, ad), y=hate
# hate가 0인 경우는 제외(log 변환이 필요하므로)
data_game_hate = data_game %>% filter(hate!=0)
game.lm.hate = lm(hate ~ ad + name, data = data_game_hate)
summary(game.lm.hate)

# 등분산성, 정규성, 등분산성(이상점), 이상점 확인
par(mfrow=c(2,2))
plot(game.lm.hate)

# 반응변수 변수변환을 위한 boxcox
library(MASS)
par(mfrow=c(1,1))
bc_game.lm.hate <- boxcox(game.lm.hate)
lambda <- bc_game.lm.hate$x[which.max(bc_game.lm.hate$y)]
lambda

# x=(name, ad), y=log(hate)
game.lm.hate.log = lm(log(hate) ~ ad + name, data = data_game_hate)
summary(game.lm.hate.log)

# 등분산성, 정규성, 등분산성(이상점), 이상점 확인
par(mfrow=c(2,2))
plot(game.lm.hate.log)
table(data_game$hate)
# 목적변수가 comm_count인 경우 -> x=(name, ad), y=comm_count

# comm_count가 0인 경우는 제외
data_game_count = data_game %>% filter(data_game$comm_count != 0)

game.lm.count = lm(comm_count ~ ad + name, data = data_game_count)
summary(game.lm.count)

# 등분산성, 정규성, 등분산성(이상점), 이상점 확인
par(mfrow=c(2,2))
plot(game.lm.count)

# 반응변수 변수변환을 위한 boxcox
par(mfrow=c(1,1))
bc_game.lm.count <- boxcox(game.lm.count)
lambda <- bc_game.lm.count$x[which.max(bc_game.lm.count$y)]
lambda

# x=(name, ad), y=log(hate)
game.lm.count.tra = lm(log(comm_count) ~ ad + name, data = data_game_count)
summary(game.lm.count.tra)


# 등분산성, 정규성, 등분산성(이상점), 이상점 확인
par(mfrow=c(2,2))
plot(game.lm.count.tra)


# 반응변수가 view인 경우 -> x=(name, ad), y=view
game.lm.view = lm(view ~ ad + name, data = data_game)
summary(game.lm.view)

# 등분산성, 정규성, 등분산성(이상점), 이상점 확인
par(mfrow=c(2,2))
plot(game.lm.view)

# 반응변수 변수변환을 위한 boxcox
par(mfrow=c(1,1))
bc_game.lm.view <- boxcox(game.lm.view)
lambda <- bc_game.lm.view$x[which.max(bc_game.lm.view$y)]
lambda

# x=(name, ad), y=log(hate)
game.lm.view.tra = lm(log(view) ~ ad + name, data = data_game)
summary(game.lm.view.tra)


