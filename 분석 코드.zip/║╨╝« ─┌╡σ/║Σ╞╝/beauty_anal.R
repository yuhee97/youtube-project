#�ʿ� ���̺귯��
library(fastDummies)
library(devtools)
library(tidyverse)
library(datarium)
library(PerformanceAnalytics)
library(rcompanion)
library("MASS")
library(lmtest)

str(mydata)

#��ó���� ���� �о����
mydata <- read.csv("cleaned_total_2019.csv", sep = ",", head = TRUE, encoding = "UTF-8")

#hate�� 0�� �ִ� ��� box-cox�� ������ hate �� 0�� �� ����
mydata_hate <- mydata[!(mydata$hate == 0), ]

#������ ������ ��ȯ
mydata$name = as.factor(mydata$name)
mydata$ad = as.factor(mydata$ad)
mydata_hate$name = as.factor(mydata_hate$name)
mydata_hate$ad = as.factor(mydata_hate$ad)
str(mydata)

#��ü ������ �м� (��ȯ ��)
model_like_lm <- lm(like ~ name + ad, data = mydata)
model_hate_lm <- lm(hate ~ name + ad, data = mydata_hate)
model_view_lm <- lm(view ~ name + ad, data = mydata)
model_comm_count_lm <- lm(comm_count ~ name + ad, data = mydata)
model_sub_lm <- lm(sub ~ name + ad, data = mydata)

summary(mydata_like)
summary(mydata_hate)
summary(mydata_view)
summary(mydata_comm_count)
summary(mydata_sub)

#��Ʃ����� ��ġ�� ���� ������ ġȯ�ϱ� ���� ���� ���� ���� -> as.factor�� �ڵ� ��ȯ�̶� �ʿ� ����.
dummy_cols(.data = mydata, select_columns = c("name"), remove_first_dummy = FALSE)
mydata_dummy = dummy_cols(.data = mydata, select_columns = c("name"), remove_first_dummy = FALSE)


#������ ���� ���캸�� ()
ggplot(data = mydata, aes(x = ad, y = like)) + geom_point(size = 1)
ggplot(data = mydata, aes(x = ad, y = view)) + geom_point(size = 1) 
ggplot(data = mydata, aes(x = ad, y = sub)) + geom_point(size = 1) 
ggplot(data = mydata, aes(x = ad, y = comm_count)) + geom_point(size = 1) 
ggplot(data = mydata, aes(x = ad, y = sub)) + geom_point(size = 1)

#�̻�ġ Ȯ��
boxplot(mydata$like)$stats
boxplot(mydata$hate)$stats
boxplot(mydata$view)$stats
boxplot(mydata$sub)$stats
boxplot(mydata$comm_count)$stats

#box-cox y ��ȯ
bc_like <- boxcox(lm(like ~ ad + name,data=mydata),lambda=seq(-1,1,by=.1))
lambda_like <- bc$x[which.max(bc$y)]
lambda_like

bc_hate <- boxcox(lm(hate ~ ad + name,data=mydata),lambda=seq(-1,1,by=.1))
lambda_hate <- bc$x[which.max(bc$y)]
lambda_hate

bc_view <- boxcox(lm(view ~ ad + name,data=mydata),lambda=seq(-1,1,by=.1))
lambda_view <- bc$x[which.max(bc$y)]
lambda_view

bc_sub <- boxcox(lm(sub ~ ad + name,data=mydata),lambda=seq(-1,1,by=.1))
lambda_sub <- bc$x[which.max(bc$y)]
lambda_sub

bc_comm_count <- boxcox(lm(comm_count ~ ad + name,data=mydata),lambda=seq(-1,1,by=.1))
lambda_comm_count <- bc$x[which.max(bc$y)]
lambda_comm_count

hist(mydata$like, breaks = 100)
hist(mydata$like^lambda - 1 / lambda, breaks = 100)

hist(mydata$hate, breaks = 100)
hist(mydata$hate^lambda - 1 / lambda, breaks = 100)

hist(mydata$view, breaks = 100)
hist(mydata$view^lambda - 1 / lambda, breaks = 100)

hist(mydata$sub, breaks = 100)
hist(mydata$sub^lambda - 1 / lambda, breaks = 100) # --�̰� �� �̻�..

hist(mydata$comm_count, breaks = 100)
hist(mydata$comm_count^lambda - 1 / lambda, breaks = 100)

model_like_lm_bc <- lm(I((like^lambda_like - 1) / lambda_like) ~ name + ad, data = mydata)
model_hate_lm_bc <- lm(I((hate^lambda_hate - 1) / lambda_hate) ~ name + ad, data = mydata_hate)
model_view_lm_bc <- lm(I((view^lambda_view - 1) / lambda_view) ~ name + ad, data = mydata)
model_sub_lm_bc <- lm(I((sub^lambda_sub - 1) / lambda_sub) ~ name + ad, data = mydata)
model_comm_count_lm_bc <- lm(I((like^lambda_comm_count - 1) / lambda_comm_count) ~ name + ad, data = mydata)

summary(model_like_lm)
summary(model_like_lm_bc)

summary(model_view_lm)
summary(model_view_lm_bc)

#������ ���µ� ������ ��
summary(model_hate_lm)
summary(model_hate_lm_bc)

summary(model_sub_lm)
summary(model_sub_lm_bc)

summary(model_comm_count_lm)
summary(model_comm_count_lm_bc)

summary(model_like_lm)
summary(model_like_lm_bc)

shapiro.test(resid(model_like_lm))
shapiro.test(resid(model_like_lm_bc))

dwtest(mydata_like)
dwtest(model_like_lm)

bptest(mydata_like)
bptest(model_like_lm)
